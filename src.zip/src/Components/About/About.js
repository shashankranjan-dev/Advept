import React from "react";

import { Link } from "react-router-dom";
import Banner from "./Banner";
import Stats from "./Stats";
import { Team } from "./Team";

function About() {
  return (
    <div>
      <Banner />

      <section class="container mx-auto  py-12">
        {/* second block start */}
        <div class="flex items-center flex-wrap ">
          <div className="xl:mx-auto xl:container">
            <div className="lg:px-20 md:px-6 px-4 md:py-0 py-8">
              <div className="flex flex-col-reverse lg:flex-row items-center">
                <div className="lg:w-1/2 lg:pl-14 lg:pr-24">
                  <p className="md:text-3xl lg:text-4xl text-2xl font-medium lg:leading-16 text-gray-800 lg:pb-6 md:pb-4 pb-2">
                    Bring your payroll
                  </p>
                  <p className="text-lg leading-7 text-justify text-gray-600 md:pb-6 pb-8">
                    Tasync allows you to track hours worked, manage benefits
                    enrollment, and run payroll all from a single platform.
                    There will be no more data duplication or tedious approval
                    processes—just simple, accurate payroll for you and your
                    employees
                  </p>
                </div>
                <div className="w-full lg:w-1/2 md:py-9 py-6">
                  <img
                    src="https://connecteam.com/wp-content/uploads/2022/03/one-stop-shpoe.png"
                    alt="bag"
                    className="lg:w-full h-full object-cover object-center w-full"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* third block start */}
        <div class="flex items-center flex-wrap ">
          <div className="xl:mx-auto xl:container">
            <div className="lg:px-20 md:px-6 px-4 md:py-0 py-8">
              <div className="flex flex-col-reverse lg:flex-row items-center">
                <div className="w-full lg:w-1/2 md:py-9 py-6">
                  <img
                    src="https://connecteam.com/wp-content/uploads/2023/02/effortlessly-commuiniction.jpg"
                    alt="bag"
                    className="lg:w-full h-full object-cover object-center w-full"
                  />
                </div>
                <div className="lg:w-1/2 lg:pl-14 lg:pr-24">
                  <p className="md:text-3xl lg:text-4xl text-2xl font-medium lg:leading-16 text-gray-800 lg:pb-6 md:pb-4 pb-2">
                    Effortlessly manage
                  </p>
                  <p className="text-lg leading-7 text-justify text-gray-600 md:pb-6 pb-8">
                    Manage your worldwide workforce with a versatile,
                    cloud-based employee management system. Build a secure,
                    comprehensive, and scalable database to get a better
                    understanding of your employees.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Stats />
      <Team />
    </div>
  );
}

export default About;

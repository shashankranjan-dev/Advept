import React from "react";
import Cont from "./Cont";

function Contact() {
  return (
    <>
      <div className="bg-gray-200">
        {" "}
        <div class="container px-5 py-28 mx-auto">
          <div class="flex flex-wrap w-full ">
            <div class="lg:w-1/2 w-full mb-6 lg:mb-0">
              <h1 class="sm:text-4xl text-2xl font-medium title-font mb-2 text-gray-900">
                Let's Visit us at Office
              </h1>
              <div class="h-1 w-20 bg-indigo-500 rounded"></div>
            </div>
            <p class="lg:w-1/2 w-full  leading-relaxed text-gray-600">
              Whatever cardigan tote bag tumblr hexagon brooklyn asymmetrical
              gentrify, subway tile poke farm-to-table. Franzen you probably
              haven't heard of them man bun deep jianbing selfies heirloom prism
              food truck ugh squid celiac humblebrag.
            </p>
          </div>
        </div>
      </div>
      <Cont />
    </>
  );
}

export default Contact;

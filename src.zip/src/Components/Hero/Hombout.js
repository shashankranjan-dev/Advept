import React from "react";
import Lottie from "lottie-react";
import animation from "./animation.json";
import { Link } from "react-router-dom";

function Hombout() {
  return (
    <div>
      <div class="bg-white py-6 sm:py-8 lg:py-6">
        <div class="mx-auto max-w-screen-xl px-4 md:px-6">
          <div class="grid gap-8 md:grid-cols-2 lg:gap-12">
            <div>
              <div class="h-full overflow-hidden   md:h-full">
                {/* <img
                  src="/Home 1.png"
                  loading="lazy"
                  alt=""
                  class="h-full w-full object-cover object-center"
                /> */}
                <Lottie
                  animationData={animation}
                  className="h-[500px] bg-none"
                />
              </div>
            </div>

            <div class="md:pt-28">
              <p class="mb-1 text-center font-bold text-indigo-500 md:text-left">
                Who we are
              </p>

              <h1 class="mb-4 text-center text-2xl font-bold text-gray-800 sm:text-3xl md:mb-4 md:text-left">
                Our competitive advantage
              </h1>

              <p class="mb-6 text-gray-500 sm:text-lg md:mb-4 text-justify">
                At Dhibar Infotech, we understand that the digital landscape is
                constantly evolving, and staying ahead of the curve is crucial.
                That's why our team is comprised of experienced professionals
                who are not only experts in their respective fields but are also
              </p>
              <br />
              <Link
                to="/about"
                class="mb-2 px-8 text-center hover:bg-indigo-600 bg-indigo-400 border border-gray-200 p-3 rounded shadow-default text-base font-semibold text-white sm:text-lg md:mb-4 md:text-left"
              >
                About us
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Hombout;
